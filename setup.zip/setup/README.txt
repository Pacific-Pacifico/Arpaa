run "ai.bat" to install LMS with parental controls

requirements:-

java 8 or above

database:-
mysql  
user - root
password- mysql

*****database - "id" with table "id_table"

command
-------

create database id;

use id;

create table id_table(
email varchar(50),
password varchar(20)
);

*****database - "login"  **no tables**

command
-------

create database login;