package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class IdTable 
{
	public IdTable(String email,String password)
	{
		String url="jdbc:mysql://localhost:3306/id";
		String user="root";
		String pass="mysql";
		String query="insert into id_table values (?,?)";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,user,pass);
			PreparedStatement st=con.prepareStatement(query);
			st.setString(1, email);
			st.setString(2, password);
			int count=st.executeUpdate();
			
			System.out.println(count + " row(s) affected");
			
			st.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
