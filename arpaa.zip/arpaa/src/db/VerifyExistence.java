package db;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VerifyExistence 
{
	public int doesExists(String db,String table_name,String email,String password)
	{	
		String url="jdbc:mysql://localhost:3306/"+db;
		String user="root";
		String pass="mysql";
		String query="Select * from "+table_name;

		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url,user,pass);
			st=(Statement)con.createStatement();
			rs=st.executeQuery(query);

			while(rs.next())
			{
//				System.out.println(rs.getString(1)+ "  "+rs.getString(2));
				String e,p;
				e=rs.getString(1);
				p=rs.getString(2);
				
				if(email.equals(e))
				{
					if(password.equals(p))
					{
						return 0;     //means email & password both match
					}
					else
					{
						return 1;     //means only email match not password
					}
				}
			}
			st.close();
			con.close();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return 2;         				//either email or both email & password didn't match
	}

	public static void main(String[] args) 
	{
		VerifyExistence ve=new VerifyExistence();
		System.out.println(ve.doesExists("id","id_table", "prashantkumar67625@gmail.com", "Pacific"));
	}
}
