package account;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

public class Credentials 
{
	Preferences preferences = Preferences.userNodeForPackage(Credentials.class);
	
	public void setCredentials(String email,String password) 
	{
		preferences.put("email", email);
		preferences.put("password", password);
		
		setFresh(false);
		setWebCam(new webcam.DetectWebCam().webCamExists());
	}
	
	public String getEmail()
	{
		return preferences.get("email", null);
	}

	public String getPassword() 
	{
		return preferences.get("password", null);
	}
	
	public void setFresh(boolean b)
	{
		preferences.putBoolean("fresh", b);
	}
	
	public boolean isFresh()
	{
		return preferences.getBoolean("fresh", true);
	}
	
	public void setWebCam(boolean b)
	{
		preferences.putBoolean("webCam",b);
	}
	
	public boolean isWebCam()
	{
		return preferences.getBoolean("webCam", false);
	}
	
	public void clearCredentials()
	{
		try 
		{
			preferences.clear();
		}
		catch (BackingStoreException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void removeCredentials()
	{
		preferences.remove("email");
		preferences.remove("password");
		preferences.remove("fresh");
		preferences.remove("webCam");
	}
	
	
	public String getModifiedEmail()
	{
		String mEmail=preferences.get("email", null);
		mEmail=mEmail.toLowerCase();
		mEmail=removeSpecialChars(mEmail);
		return mEmail;
	}
	
	static String removeSpecialChars(String email)
	{
		String[] arrOfStr = email.split("[@.]"); 
		StringBuilder modified=new StringBuilder();  
        for (String a : arrOfStr)
        {
            System.out.println(a);
            modified.append(a);
        }
        return new String(modified);
	}
	
	public static void main(String[] args) 
	{
		Credentials c=new Credentials();
		c.clearCredentials();
//		System.out.println(c.getPassword());
//		c.setCredentials("prashantkumar67625@gmail.com", "Pacific");
//		System.out.println(c.getEmail());
//		System.out.println(c.getPassword());
//		c.setFresh(false);
//		c.setFresh(true);
//		System.out.println(c.isFresh());
		
//		c.setWebCam(new webcam.DetectWebCam().webCamExists());
	}
}
