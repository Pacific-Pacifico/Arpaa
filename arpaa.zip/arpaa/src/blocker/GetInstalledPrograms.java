package blocker;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class GetInstalledPrograms 
{
	public static void main(String[] args) 
	{
		File f=null;
        FileWriter fw=null;
        PrintWriter pw=null;
		BufferedReader reader=null;
		StringBuilder sb=new StringBuilder("");
		try
		{
//		 String command="powershell -command \"Get-ItemProperty "
//		 	+ "HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | "
//		 	+ "Select-Object DisplayName, DisplayVersion, InstallLocation,InstallSource,InstallDate,Publisher "
//		 	+ "| Format-Table �AutoSize\"";
			
			String command="powershell -command \"Get-ItemProperty "
				 	+ "HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | "
				 	+ "Select-Object DisplayName,InstallLocation "
				 	+ "| Format-Table �AutoSize\""; 
		 //ProcessBuilder builder = new ProcessBuilder(command); 
         //Process p = builder.start();
		 Process p = Runtime.getRuntime().exec(command);
         //p.waitFor();
         reader= new BufferedReader(new InputStreamReader(p.getInputStream()));
         
         //file related commands
         f=new File("C:\\Users\\Public\\Arpaa\\Logs\\all_programs.txt");
         fw=new FileWriter(f);
         pw=new PrintWriter(fw);
         
         String line = "";
         while ((line = reader.readLine()) != null) {
        	 //append to StringBuilder sb to display at console
             sb.append(line + "\n");
             //write to file
             pw.println(line);
         }
         System.out.println(sb);

         
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
}
