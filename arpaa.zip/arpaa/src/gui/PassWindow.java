package gui;

import java.awt.*;
import javax.swing.*;

import java.awt.event.*;
import java.io.File;

class PassFrame extends JFrame implements ActionListener
{
	Container c;
	JLabel l_pass;
	JPasswordField pass;
	JButton ok,cancel;
	String enteredPass,originalPass;
	int attempts=3;
	
	public PassFrame()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		l_pass=new JLabel("Enter Password:");
		pass=new JPasswordField();
		ok=new JButton("Ok");
		cancel=new JButton("Cancel");
		
		originalPass=new account.Credentials().getPassword();
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		l_pass.setBounds(20,10 ,200 ,25 );
		
		pass.setBounds(150, 10,250 ,25 );
	
		ok.setBounds(200, 50,100 , 40);
		cancel.setBounds(320, 50, 100,40 );
	}
	
	void windowSetter()
	{
		setTitle("Login Monitor Software");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500,300,450,150);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(l_pass);
		c.add(pass);
		
		c.add(ok);
		c.add(cancel);
	}
	
	void eventSetter()
	{
		this.addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e)
			{
				pass.requestFocus();
			}
			
			public void windowActivated(WindowEvent e)
			{
				pass.requestFocus();
			}
		});
		
		ok.addActionListener(this);
		cancel.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==ok)
		{
			attempts--;
			enteredPass=new String(pass.getPassword());
			if(enteredPass.equals(originalPass))
			{
				new MWindow();
				dispose();
			}
			else if(attempts==0)
			{
				boolean b=new account.Credentials().isWebCam();
				if(b==true)
				{
					String dt;
					dt=new date.CurrentDateTime().getCurrentDateTime();
					new webcam.TakePicture(new File("C:\\Users\\Public\\Arpaa\\Logs\\pics\\" +dt+ ".png"));
				}
				System.exit(1);
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Invalid Password!! Attempts remaining="+attempts);
				pass.setText("");
			}
		}
		else if(e.getSource()==cancel)
		{
			System.exit(2);
		}
	}
}

public class PassWindow
{
	public static void main(String[] args) 
	{
		Boolean b;
		b=new account.Credentials().isFresh();
		if(b==true)
		{
			new account.Welcome();
		}
		else if(b==false)
		{
			PassFrame pf=new PassFrame();
		}
	}
}