package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HelpGUI extends JFrame implements ActionListener
{	
	Container c;
	JButton read,feedback;
	
	public HelpGUI()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		read=new JButton("Read Documentation");
		feedback=new JButton("Send Us Feedback/Ask");
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		read.setBounds(25,200 ,200 ,100 );
		feedback.setBounds(250,200 , 200,100 );
	}
	
	void windowSetter()
	{
		setTitle("HELP");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(500,200,500,500);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(read);
		c.add(feedback);
	}
	
	void eventSetter()
	{
		read.addActionListener(this);
		feedback.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==read)
		{
			dispose();
		}
		else if(e.getSource()==feedback)
		{
			JOptionPane.showMessageDialog(this, "Email us at lms.pc.software@gmail.com");
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		HelpGUI d=new HelpGUI();
	}
	

}
