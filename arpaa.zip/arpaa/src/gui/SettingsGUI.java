package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class SettingsGUI extends JFrame implements ActionListener
{	
	Container c;
	JTabbedPane tp;
	
	JButton apply,cancel;
//	JTextArea jta;
	SettingsProperties sp;
	
	public SettingsGUI()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
//		jta=new JTextArea(625,600);
//		jta.setEditable(true);
//		create=new JButton("Create Account");
//		login=new JButton("Login");
		tp=new JTabbedPane();
		
		apply=new JButton("Apply");
		cancel=new JButton("Cancel");
		
		apply.setEnabled(false);
		cancel.setEnabled(false);
		
		sp=new SettingsProperties();
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		tp.setSize(625, 500);
//		tp.setBounds(25,50,475,475);
		apply.setBounds(250,525 ,150 ,75 );
		cancel.setBounds(450,525 , 150,75 );
	}
	
	void windowSetter()
	{
		setTitle("Settings");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(500,200,650,650);
		setResizable(false);
	}
	
	void componentsAdder()
	{
//		P_general.add(jta);
		c.add(tp);
		c.add(apply);
		c.add(cancel);
		
		tp.add("General",new P_general(this,sp));
		tp.add("Email",new P_email(this,sp));
		tp.add("Webcam",new P_webcam(this,sp));
		
		
	}
	
	void eventSetter()
	{
		apply.addActionListener(this);
		cancel.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==apply)
		{
			dispose();
		}
		else if(e.getSource()==cancel)
		{
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		SettingsGUI d=new SettingsGUI();
//		SettingsProperties sp=new SettingsProperties();
//		sp.writeProperties();
//		sp.readProperties();
	}
}

class P_general extends JPanel
{
	SettingsGUI obj;
	JCheckBox pb,sb;
	
	P_general(SettingsGUI obj,SettingsProperties sp)
	{
		this.obj=obj;
//		System.out.println(getLayout());
		setLayout(null);
//		System.out.println(getLayout());
		pb=new JCheckBox("Turn on program blocking feature");
		sb=new JCheckBox("Turn on site blocking feature");
//		wc.setLocation(125, 150);
		pb.setBounds(25, 25, 300, 100);
		sb.setBounds(25,100,300,100);
		add(pb);
		add(sb);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		pb.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
		
		sb.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);

			}
		});
	}
}

class P_email extends JPanel
{
	SettingsGUI obj;
	JCheckBox e;
	
	P_email(SettingsGUI obj,SettingsProperties sp)
	{
		this.obj=obj;
//		System.out.println(getLayout());
		setLayout(null);
//		System.out.println(getLayout());
		e=new JCheckBox("Turn on email facility");
		e.setSelected(Boolean.parseBoolean(sp.getEmailKey()));
//		wc.setLocation(125, 150);
		e.setBounds(25, 25, 200, 100);
		add(e);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		e.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
	}
}

class P_webcam extends JPanel
{
	SettingsGUI obj;
	JCheckBox wc;
	
	P_webcam(SettingsGUI obj,SettingsProperties sp)
	{
		this.obj=obj;
//		System.out.println(getLayout());
		setLayout(null);
//		System.out.println(getLayout());
		wc=new JCheckBox("Turn on Webcam facility");
		wc.setSelected(Boolean.parseBoolean(sp.getWebcamKey()));
//		wc.setLocation(125, 150);
		wc.setBounds(25, 25, 200, 100);
		add(wc);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		wc.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
	}
}	

class SettingsProperties
{
	Properties p;
	FileReader fr;
	FileWriter fw;
	String[] keys={"email_key","webcam_key"};;
	
	SettingsProperties() 
	{
		p=new Properties();
	}
	
	void writeProperties()
	{
		try {
			fw=new FileWriter("C:\\Users\\Public\\Arpaa\\Logs\\config.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		p.setProperty("email_key","true");
		p.setProperty("webcam_key", "false");
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	void readProperties()
	{
		try {
			fr=new FileReader("C:\\Users\\Public\\Arpaa\\Logs\\config.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			p.load(fr);
		} catch (IOException e) {
			e.printStackTrace();
		}
//		System.out.println("value of email: "+p.getProperty("email_key"));
//		System.out.println("value of webcam: "+p.getProperty("webcam_key"));
	}
	
	String getEmailKey()
	{
		readProperties();
		return p.getProperty("email_key");
	}
	
	String getWebcamKey()
	{
		readProperties();
		return p.getProperty("webcam_key");
	}
}
	
