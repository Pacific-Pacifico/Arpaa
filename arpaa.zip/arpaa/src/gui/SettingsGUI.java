package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class SettingsGUI extends JFrame implements ActionListener
{	
	Container c;
	JTabbedPane tp;
	
	JButton apply,cancel,reset;
//	JTextArea jta;
	SettingsConfigProperties sp;
	
	public SettingsGUI()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
//		jta=new JTextArea(625,600);
//		jta.setEditable(true);
//		create=new JButton("Create Account");
//		login=new JButton("Login");
		tp=new JTabbedPane();
		
		apply=new JButton("Apply");
		cancel=new JButton("Cancel");
		reset=new JButton("Reset Settings");
		
		apply.setEnabled(false);
		cancel.setEnabled(false);
		
		sp=new SettingsConfigProperties();
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		tp.setSize(625, 500);
//		tp.setBounds(25,50,475,475);
		reset.setBounds(50, 525,150 ,75 );
		apply.setBounds(250,525 ,150 ,75 );
		cancel.setBounds(450,525 , 150,75 );
	}
	
	void windowSetter()
	{
		setTitle("Settings");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(500,200,650,650);
		setResizable(false);
	}
	
	void componentsAdder()
	{
//		P_general.add(jta);
		c.add(tp);
		c.add(reset);
		c.add(apply);
		c.add(cancel);
		
		tp.add("General",new P_general(this,sp));
		tp.add("Email",new P_email(this,sp));
		tp.add("Webcam",new P_webcam(this,sp));
		
		boolean b=new account.Credentials().isWebCam();
		if(b)
		{
			tp.setEnabledAt(2, true);
		}
		else
		{
			tp.setEnabledAt(2, false);
		}
	}
	
	void eventSetter()
	{
		reset.addActionListener(this);
		apply.addActionListener(this);
		cancel.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==reset)
		{
			int op=JOptionPane.showConfirmDialog(this,"Are you sure to Reset Settings?","Confirmation Message",
					JOptionPane.YES_NO_OPTION);
			if(op==JOptionPane.YES_OPTION)
			{
				sp.resetSettings();
				JOptionPane.showMessageDialog(this, "Settings have been reset");
				dispose();
				new SettingsGUI();
			}
		}
		else if(e.getSource()==apply)
		{
			if(P_general.cb_pb.isSelected())
			{
				new blocker.StartProgramsBlocker().startPB();
				sp.setPBKey(new String("true"));
			}
			else
			{
				new blocker.StopProgramsBlocker().stopPB();
				sp.setPBKey(new String("false"));
			}
			
			if(P_general.cb_sb.isSelected())
			{
				
				sp.setSBKey(new String("true"));
			}
			else
			{
				
				sp.setSBKey(new String("false"));
			}
			
			if(P_email.cb_email.isSelected())
			{
				
				sp.setEmailKey(new String("true"));
			}
			else
			{
				
				sp.setEmailKey(new String("false"));
			}
			
			if(P_webcam.cb_webcam.isSelected())
			{
				sp.setWebcamKey(new String("true"));
			}
			else
			{
				sp.setWebcamKey(new String("false"));
			}
			apply.setEnabled(false);
			cancel.setEnabled(false);
		}
		else if(e.getSource()==cancel)
		{
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		SettingsGUI d=new SettingsGUI();
	}
}

class P_general extends JPanel
{
	SettingsGUI obj;
	public static JCheckBox cb_pb,cb_sb;
	
	P_general(SettingsGUI obj,SettingsConfigProperties sp)
	{
		this.obj=obj;
//		System.out.println(getLayout());
		setLayout(null);
//		System.out.println(getLayout());
		cb_pb=new JCheckBox("Turn on program blocker");
		cb_pb.setSelected(Boolean.parseBoolean(sp.getPBKey()));
		
		cb_sb=new JCheckBox("Turn on site blocker");
		cb_sb.setSelected(Boolean.parseBoolean(sp.getSBKey()));
		
		cb_pb.setBounds(25, 25, 300, 100);
		cb_sb.setBounds(25,100,300,100);
		add(cb_pb);
		add(cb_sb);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		cb_pb.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
		
		cb_sb.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);

			}
		});
	}
}

class P_email extends JPanel
{
	SettingsGUI obj;
	public static JCheckBox cb_email;
	
	P_email(SettingsGUI obj,SettingsConfigProperties sp)
	{
		this.obj=obj;
		setLayout(null);
		cb_email=new JCheckBox("Turn on email facility");
		cb_email.setSelected(Boolean.parseBoolean(sp.getEmailKey()));
		cb_email.setBounds(25, 25, 200, 100);
		add(cb_email);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		cb_email.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
	}
}

class P_webcam extends JPanel
{
	SettingsGUI obj;
	public static JCheckBox cb_webcam;
	
	P_webcam(SettingsGUI obj,SettingsConfigProperties sp)
	{
		this.obj=obj;
		setLayout(null);
		cb_webcam=new JCheckBox("Turn on Webcam facility");
		cb_webcam.setSelected(Boolean.parseBoolean(sp.getWebcamKey()));
		cb_webcam.setBounds(25, 25, 200, 100);
		add(cb_webcam);
		
		eventSetter();
	}
	
	void eventSetter()
	{
		cb_webcam.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				obj.apply.setEnabled(true);
				obj.cancel.setEnabled(true);
				
			}
		});
	}
}	

	
