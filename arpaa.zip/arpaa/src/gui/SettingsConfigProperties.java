package gui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class SettingsConfigProperties
{
	Properties p;
	FileReader fr;
	FileWriter fw;

	public SettingsConfigProperties() 
	{
		p=new Properties();
	}

	void writeToFile()
	{
		try {
			fw=new FileWriter("C:\\Users\\Public\\Arpaa\\Logs\\config.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void readFromFile()
	{
		try {
			fr=new FileReader("C:\\Users\\Public\\Arpaa\\Logs\\config.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			p.load(fr);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeProperties()
	{
		writeToFile();
		p.setProperty("pb_key", "true");
		p.setProperty("sb_key", "true");
		p.setProperty("email_key","true");
		
		account.Credentials ac=new account.Credentials();
		boolean b=ac.isWebCam();
		ac.setWebCamUsable(b);
		p.setProperty("webcam_key", String.valueOf(b));
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readProperties()
	{
		readFromFile();
		System.out.println("value of pb: "+p.getProperty("pb_key"));
		System.out.println("value of sb: "+p.getProperty("sb_key"));
		System.out.println("value of email: "+p.getProperty("email_key"));
		System.out.println("value of webcam: "+p.getProperty("webcam_key"));
	}

	void setPBKey(String value)
	{
		writeToFile();
		p.setProperty("pb_key", value);
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void setSBKey(String value)
	{
		writeToFile();
		p.setProperty("sb_key", value);
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void setEmailKey(String value)
	{
		writeToFile();
		p.setProperty("email_key", value);
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void setWebcamKey(String value)
	{
		writeToFile();
		p.setProperty("webcam_key", value);
		try {
			p.store(fw,"configuration for settings");
		} catch (IOException e) {
			e.printStackTrace();
		}
		new account.Credentials().setWebCamUsable(Boolean.parseBoolean(value));
	}

	String getPBKey()
	{
		readFromFile();
		return p.getProperty("pb_key");
	}
	
	String getSBKey()
	{
		readFromFile();
		return p.getProperty("sb_key");
	}
	
	String getEmailKey()
	{
		readFromFile();
		return p.getProperty("email_key");
	}

	String getWebcamKey()
	{
		readFromFile();
		return p.getProperty("webcam_key");
	}
	
	void resetSettings()
	{
		writeProperties();
	}

	public static void main(String[] args) 
	{
		SettingsConfigProperties sp=new SettingsConfigProperties();
		sp.writeProperties();
		sp.readProperties();
	}
}
