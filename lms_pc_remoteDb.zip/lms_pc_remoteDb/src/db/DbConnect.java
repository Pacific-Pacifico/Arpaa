package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnect 
{
	Connection con=null;
	String user,pass;
	
	
	public Connection getDbConnection(String db_name)
	{

//		String url="jdbc:mysql://localhost:3306/"+db_name;
//		user="root";
//		pass="mysql";

		if(db_name.equals("id"))
		{
			db_name="R0b5ObbmAQ";
			user="R0b5ObbmAQ";
			pass="tYvXiNyKz2";
		}
		else if(db_name.equals("login"))
		{
			db_name="F4EbK5IIrw";
			user="F4EbK5IIrw";
			pass="sWTK3n7m56";
		}

		String url="jdbc:mysql://remotemysql.com:3306/"+db_name;
		

		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url,user,pass);
			System.out.println(con);
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return con;
	}
}
